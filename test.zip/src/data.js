const ad = {
    ads: [{
        id: 1,
        text: ' Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam, ipsum!'
    },
    {
        id: 2,
        text: ' Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam, Second'
    },
    {
        id: 3,
        text: ' Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam, Third'
    },
    {
        id: 4,
        text: ' Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam, Fourth'
    },{
        id: 5,
        text: ' Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam, ipsum!'
    },
    {
        id: 6,
        text: ' Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam, Second'
    },
    {
        id: 7,
        text: ' Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam, Third'
    },
    {
        id: 8,
        text: ' Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam, Fourth'
    },
    {
        id: 9,
        text: ' Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam, Fourth'
    },
    {
        id: 10,
        text: ' Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam, Fourth'
    },
    {
        id: 11,
        text: ' Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam, Fourth'
    },
    {
        id: 12,
        text: ' Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam, Fourth'
    },
    {
        id: 13,
        text: ' Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam, Fourth'
    },
    {
        id: 14,
        text: ' Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam, Fourth'
    },
    {
        id: 15,
        text: ' Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam, Fourth'
    },
    {
        id: 16,
        text: ' Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam, Fourth'
    },

]
}
export default ad