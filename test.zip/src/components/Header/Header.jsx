import './Header.scss'
const Header = () => {
    return (
        <nav className = 'nav'>
            <ul className="nav__navbar">
                <li className="nav__item"><a href='##' className = 'nav__link'>Lorem.</a></li>
                <li className="nav__item"><a href="##" className="nav__link">Lorem.</a></li>
                <li className="nav__item"><a href="##" className="nav__link">Lorem.</a></li>
                <li className="nav__item"><a href="##" className="nav__link">Lorem.</a></li>
                <li className="nav__item"><a href="##" className="nav__link">Lorem.</a></li>
                <li className="nav__item"><a href='##' className='nav__link'>Lorem.</a></li>
                <li className="nav__item"><a href="##" className="nav__link">Lorem.</a></li>
                <li className="nav__item"><a href="##" className="nav__link">Lorem.</a></li>
                <li className="nav__item"><a href="##" className="nav__link">Lorem.</a></li>
                <li className="nav__item"><a href="##" className="nav__link">Lorem.</a></li>
                <li className="nav__item"><a href="##" className="nav__link">Lorem.</a></li>
            </ul>
        </nav>
    );
};

export default Header;