import { createContext } from 'react';

const PinsContext = createContext();

export default PinsContext;
